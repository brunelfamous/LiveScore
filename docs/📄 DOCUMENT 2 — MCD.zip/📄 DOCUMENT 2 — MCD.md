﻿📄 DOCUMENT 2 — MCD (VERSION EXPLIQUÉE)

🧩 1. Entités principales

👤 Organisateur

id

name

email

password

role

🏆 Tournoi

id

name

location

dates

organizerId

status

🛡️ Équipe

id

name

tournamentId

👟 Joueur (optionnel MVP)

id

name

number

teamId

⚽ Match

id

tournamentId

teamAId

teamBId

scoreA

scoreB

status (scheduled, live, finished)

date

🔥 Événement

id

matchId

teamId

playerId (optionnel)

type (goal, yellow\_card, red\_card)

createdAt

🔗 2. Relations

1. organisateur → plusieurs tournois
1. tournoi → plusieurs équipes
1. tournoi → plusieurs matchs
1. équipe → plusieurs joueurs
1. match → plusieurs événements

🔐 3. Règles de gestion

Un organisateur ne peut modifier que ses tournois

Un match appartient à un seul tournoi

Un événement appartient à un seul match

Le score est mis à jour via les événements

⚙️ 4. Logique backend

Quand un événement est créé :

Ajouter événement

Mettre à jour score

Envoyer update temps réel

📦 5. Choix techniques

Backend : Node.js + Express

Temps réel : Socket.IO

Base de données : MongoDB

Frontend : Flutter
