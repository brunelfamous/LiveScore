﻿📄 DOCUMENT 1 — VISION DU PROJET (VERSION PROPRE)

🧠 1. Contexte et idée

Le projet consiste à développer une application mobile permettant de suivre en direct des matchs de tournois locaux (quartiers, écoles, communautés).

L’objectif est de résoudre un problème simple :

Aujourd’hui, les petits tournois n’ont pas de visibilité en temps réel.

Les scores ne sont pas centralisés, et les supporters ne peuvent pas suivre les matchs à distance.

👉 L’application devient donc une plateforme de live score locale et communautaire.

🎯 2. Vision du produit

Le produit n’est pas juste une app de score.

👉 C’est une plateforme où plusieurs organisateurs peuvent gérer leurs propres tournois en autonomie, pendant que les utilisateurs consultent les matchs en direct.

👥 3. Types d’utilisateurs

👑 Super Admin (nous)

Gère toute la plateforme

Peut voir tous les tournois

Peut créer des organisateurs

🧑‍💼 Organisateur (gestionnaire)

A un compte (email + mot de passe)

Gère uniquement ses tournois

Peut :

créer équipes

créer matchs

lancer un match en LIVE

mettre à jour score

ajouter événements (but, carton…)

👉 Important :

❌ Il n’a pas accès aux autres tournois

❌ Il n’a pas accès au panel admin global

👀 Utilisateur (public)

Pas de compte (au début)

Peut :

voir les tournois

voir les matchs

suivre les scores en direct

🏆 4. Fonctionnement global

📅 Avant le match

L’organisateur crée :

tournoi

équipes

matchs (date + heure)

👉 Les utilisateurs voient :

matchs à venir

🔴 Pendant le match (LIVE)

L’organisateur :

passe le match en LIVE

met à jour score manuellement

ajoute événements (but, carton…)

👉 Les utilisateurs voient en temps réel :

score

statut LIVE

événements

✅ Après le match

Match marqué comme terminé

Historique disponible

⚡ 5. Temps réel (élément clé)

Quand un organisateur met à jour :

score

événement

👉 Tous les utilisateurs voient instantanément la mise à jour.

👉 Implémentation prévue :

WebSockets (Socket.IO)

🧠 6. Choix importants (décisions produit)

✔ Multi-organisateurs

Plusieurs organisateurs peuvent utiliser l’app en même temps

✔ Multi-tournois

Un organisateur peut gérer plusieurs tournois

Limite recommandée :

1. à 3 tournois au début (scalabilité + futur business)

✔ Authentification simple

Email + mot de passe

Pas de système complexe au début

✔ Pas de gestion du temps réel du match (chronomètre)

Pas de minute exacte (ex: 67’)

Trop compliqué et pas fiable sur terrain

👉 À la place :

timestamp automatique (heure système)

affichage type :

“il y a 2 min”

📱 7. Fonctionnalités MVP

Utilisateur

Voir liste des tournois

Voir matchs (à venir / live / terminé)

Voir score en direct

Organisateur

Créer tournoi

Créer équipes

Créer matchs

Modifier statut :

scheduled

live

finished

Modifier score

Ajouter événements

🔥 8. Fonctionnalités avancées (plus tard)

Notifications push

Favoris d’équipes

Classement tournoi

Statistiques joueurs

Sponsors

Pages personnalisées tournoi

💡 9. UX importante (terrain)

Mode “gestion rapide” :

bouton ⚽ BUT

bouton 🟨 CARTON

modification rapide du score

👉 Interface simple pour usage sur terrain

🚀 10. Vision long terme

Plateforme utilisée par plusieurs quartiers

Adoption communautaire

Possibilité de monétisation :

abonnements organisateurs

publicité locale
